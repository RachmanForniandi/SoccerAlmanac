package com.example.socceralmanac.models.detail_league

data class RootDetailLeague(
	val leagues: List<DetailLeaguesItem?>? = null
)
